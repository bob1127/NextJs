import ProductRating from "./ProductRating";

export { ProductRating };
