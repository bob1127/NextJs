module.exports = {
  env: {
    PUBLIC_URL: ""
  }
};
